#from RuleGenerator import *

from sets import *
import Apriori
import FPGrowth




 

''' FPGrowth '''

# flag is either 'boolean' or 'stringvalues' 
# pop = colname to get rid of
print '*********************************************'
print '### START FP-GROWTH ###'
fp = FPGrowth.FPGrowth(2, 'test.csv', 'stringvalues', 'id')



''' APRIORI '''
print 'Found frequent sets (longer than 1 item) are :'
transformedFreqs = []
for freq in fp.frequentItemsSets :
	if len(freq[0]) > 1 :
		transformedFreqs.append(freq[0])
print transformedFreqs

print '*********************************************'
print '### START APRIORI ###'
print '(only take rules with 100% confidence)'
apriori = Apriori.Apriori(fp.states, fp.table, 1)
frequent_sets = transformedFreqs
apriori.rule_generation(frequent_sets)
print '*********************************************'

'''
apriori = Apriori.Apriori('test.csv')
frequent_sets = [[(' HLA', ' A*04'), (' Sequence', ' G'), (' Tumor', ' a')]]
apriori.rule_generation(frequent_sets)
'''
