from FPGrowth import *
from FPGrowthNode import *

def buildTree(root, transactions, minsup) :
	''' row wise adding transactions (sets of items) to a given root
		return tree as root and dict of items last nodes
	'''
	lastNodeOfItem = dict()
	for trans in transactions :
		where = root
		for item in trans :
			if where.hasAsNext(item) :
				where = where.goToNext(item)
			else :
				where.addNext(item)
				where = where.goToNext(item)
				if item in lastNodeOfItem :
					where.same = lastNodeOfItem[item]
				lastNodeOfItem[item] = where
			where.increment()
	return FPTree(root, lastNodeOfItem, minsup)


def findTransactions(table, states) :
	''' transactions are equivalent to path in tree 
		given a table of boolean item
		appending states to a list
		return it sorted!
	'''
	trans = []
	for row in table :
		t = []
		i = 0
		for item in row :
			if item:
				t.append(states[i])
			i = i + 1
		t.sort()
		trans.append(t)
	return trans


def builtPrefixTree(item, itemSet, tree) :
	''' builds Prefix tree of item given a tree
		items of itemSet are already cut off (carried as additional information)
		paths is a list of path-Tuples (itemset, support of item in Prefix tree)
	'''
	# get all suffix Nodes
	lastNode = tree.lastNodeOfItem[item]
	suffixNodes = getSameNodesAs(lastNode)

	# check item Support
	itemSupport = freqOfItem(item, suffixNodes)
	if itemSupport < tree.minsupport :
		return nullTree()

	# if item Support high enough
	paths = []
	for node in suffixNodes :
		currentNode = node
		itemCount = node.count
		path = []
		while not currentNode.isRoot() :
			path.append(currentNode.label)
			currentNode = currentNode.parent
		paths.append((path, itemCount))
		prefixTree = builtPrefixTreeForWeightedPaths(item, itemSet, paths, tree.minsupport)
	return prefixTree


def builtPrefixTreeForWeightedPaths(item, itemSet, paths, minsupport) :
	''' given generated paths for Prefix tree of (item + itemSet)
		todo : built new FPTree Object
	'''
	what = [item]
	for i in itemSet :
		what.append(i)
	pT = constructRoot('Tree of %s' %str(what))
	lastNodeOfItem = dict()

	for path in paths :
		items = path[0] #revers sorted
		weight = path[1]
		where = pT

		i = len(items)-1
		while i >= 0 :
			currentItem = items[i]
			if where.hasAsNext(currentItem) :
				where = where.goToNext(currentItem)
				where.count = where.count + weight
			else :
				where.addNext(currentItem)
				where = where.goToNext(currentItem)
				if currentItem in lastNodeOfItem :
					where.same = lastNodeOfItem[currentItem]
				lastNodeOfItem[currentItem] = where
				where.count = where.count + weight
			i = i - 1
	return FPTree(pT, lastNodeOfItem, minsupport)


def getSameNodesAs(lastNode) :
	''' Return : list of nodes with same label as lasNode
		only takes lastNode from FPTree.lastNodeOfItem
	'''
	nodes = [lastNode]
	while not lastNode.same.isNullNode() :
		nodes.append(lastNode.same)
		lastNode = lastNode.same
	return nodes

def freqOfItem(item, nodes) :
	''' sum over node.count for node in nodes
	'''
	itemFreq = 0
	for node in nodes :
		itemFreq = itemFreq + node.count
	return itemFreq
	

def getNodeFreq(node) :
	''' takes only lastNodeofItem
		sum over count of nodes with item like lastNodeofItem
	'''
	freq = node.count
	lastNode = node
	while not lastNode.same.isNullNode() :
		freq = freq + lastNode.same.count
		lastNode = lastNode.same
	return freq
	

def kickInfreqItemsFrom(pT, item) :
	''' kick infreq items
		and new item (to cut off leaves)
	'''
	kick = [item]
	for i in pT.lastNodeOfItem :
		node = pT.lastNodeOfItem[i]
		nodeFreq = getNodeFreq(node)
		if nodeFreq < pT.minsupport :
			kick.append(node.label)
			eliminateItemFrom(node.label, pT.root)
	eliminateItemFrom(item, pT.root)
	
	for k in kick :
		del(pT.lastNodeOfItem[k])
	if len(pT.root.next) == 0 :
		return nullTree()
	return pT

def eliminateItemFrom(item, node) :
	''' helper for kickInfreqItemsFrom
		eliminates identified item from tree node
	'''
	if node.isNullNode() :
		return
	for nextNode in node.next :
		if nextNode.hasLabel(item) :
			node.next = node.next + nextNode.next
			node.next.pop(node.next.index(nextNode))
		else :
			eliminateItemFrom(item, nextNode)



def copyList(l) :
	newList = []
	for item in l :
		newList.append(item)
	return newList

	
			











