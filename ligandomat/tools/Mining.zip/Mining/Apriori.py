#from RuleGenerator import *
import DataForming
from sets import *

class Apriori() :
	''' The Apriori-Algorithm generates associative rules
		based on given frequent sets.
		The minconfidence sets the minimal value for rule set_a -> set_b
		of the ratio support(set_a+set_b)/support(set_a)
		In this implementation the boolean table and states are only needed
		to calculate the support count.
	'''	
	rules = []

	def __init__(self, states, table, minconfidence) :
		self.states = states
		self.table = table
		self.mincon = minconfidence

	def rule_generation(self, frequent_sets) :
		''' beginning of Rule Generation
			the set H_1 is a set of lists with exactly one element of a frequent set
		'''
		for freq_set in frequent_sets :
			print '----- frequent set : %s ---------' %str(freq_set)
			H_1 = []
			for i in freq_set :
				H_1.append([i])
			self.ap_genrules(freq_set, H_1)

	def ap_genrules(self, itemset, H_m) :
		''' H_m is a list of possible consequences. It cannot be empty.
			If the consequences have length 1 -> generate one-consequence rules.
			Usually H_next (list of consequences with one more element than H_m) is generated
			and checked wheather support(set_a+c)/support(c) is larger than minconfidence with c in H_next.
			Rules are stored as 4-Tuple (<diff_itemset>, <consequence_itemset>, <confidence>, <itemset_support>)
		'''
		k = len(itemset)
		if len(H_m) == 0 :
			print 'ERROR empty H_m'
			return
		else :
			m = len(H_m[0])
		if m == 1 :
			self.ap_genrules_one_consequence(itemset)
		
		if (k > m+1) :
			H_next = self.apriori_gen(H_m)
			for consequence in H_next :
				s_itemset = self.support_count(itemset)
				diff = self.item_diff(itemset, consequence)
				s_diff = self.support_count(diff) 
				confi = s_itemset/s_diff
				if confi >= self.mincon  and len(diff) != 0:
					print '$ Rule : %s -> %s $' %(diff, consequence)
					self.rules.append((diff, consequence, confi, s_itemset))
				else :
					# remove unwanted consequence [possible in loop "for consequence in H_next"? XXX]
					H_next = self.item_diff(H_next, consequence)
			# next level
			self.ap_genrules(itemset, H_next)

	def ap_genrules_one_consequence(self, itemset) :
		''' special case of only one item in consequence
			main difference : H_next is not generated
		'''
		for consequence in itemset :
			s_itemset = self.support_count(itemset)
			diff = self.item_diff(itemset, [consequence])
			s_diff = self.support_count(diff) 
			confi = s_itemset/s_diff
			if confi >= self.mincon  and len(diff) != 0:
				print '$ Rule : %s -> %s $' %(diff, consequence)
				self.rules.append((diff, consequence, confi, s_itemset))

	def apriori_gen(self, H_m) :
		''' merge k-1-itemsets where they only differ by last item (lexicographically ordered)
			uses devide and conquer strategy
			source : http://de.wikipedia.org/wiki/Apriori-Algorithmus#Apriori-Gen
		'''
		consequences = self.apriori_gen_rec(H_m, 0)
		return consequences

	def apriori_gen_rec(self, H_m, index) :
		''' recursion of apriori_gen 
			picks first consequence as compare element and looks in others, where they differ to it
			If a different letter item is found at index -> devide H_m into two lists
			the first half has every item up until index in common, second half needs a check at index again
			Arriving at the last index -> merge of itemsets, that only differ by the last item
		'''
		if index == (len(H_m[0])-1) :
			return self.apriori_gen_merge(H_m)
		if len(H_m) > 1 :
			compare = H_m[0][index]
			for i in range(0, len(H_m)) :
				if not H_m[i][index] == compare :
					left = self.apriori_gen_rec(H_m[0:i], index+1)
					right = self.apriori_gen_rec(H_m[i:len(H_m)], index)
					return left.append(right)
		else :
			print 'no match found for %s' %H_m

	def apriori_gen_merge(self, H_m) :
		''' Input : itemsets, that only differ by the last item.
			The items, that appear in every set are token as static
			Every combination of two different items are added to static
			to gain H_next
		'''
		m = len(H_m[0])
		if len(H_m[0]) == 1 :
			static = []
		else :
			static = H_m[0][0:len(H_m)-2] 
		var = []
		output = []

		for i in range(0, len(H_m)) :
			var.append(H_m[i][m-1])

		for i in range(0, len(var)-1) :
			for j in range(i+1, len(var)) :
				lis = []
				if not static == [] :
					lis.append(static)
				lis.append(var[i]) 
				lis.append(var[j])
				output.append(lis)
		return output

	def support_count(self, itemset) :
		''' The support count represents the amount of appearance 
			of an itemset in the boolean table.
		'''
		count = 0
		for row in self.table :
			check = True
			for item in itemset :
				index = self.states.index(item)
				check = check & row[index]
			if check :
				count = count + 1
		return count
				
	def item_diff(self, set1, set2) :
		''' Input : two itemsets set1 and set2
			return : set1 / set2
		'''
		res = self.copyItemList(set1)
		for item in set2 :
			if item in res :
				res.pop(res.index(item))
		return res

	def copyItemList(self, items) :
		result = []
		for item in items :
			result.append(item)
		return result
		


