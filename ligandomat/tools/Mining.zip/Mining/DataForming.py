from Reader import *
''' 
input : relative path to .csv
output : tuple (states, list of boolean lists for each individuum)
'''

def makeBooleanTable_popId(csv_path, id) :
	
	dicts = cleverDictReader(csv_path)
	for d in dicts :
		d.pop(id)
	first = dicts[0]
	cols = len(first)

	# list of tuples : (colname, [appearances])
	list_appearances = []
	for col in first :
		l = []
		for d in dicts :
			if not d[col] in l :
			   l.append(d[col])
		list_appearances.append((col,l))

	### Making List of all possible binary states ####
	states1 = []
	for col in list_appearances :
		for appear in col[1] :
			states1.append((str(col[0]), appear))  
	states = sortItems(states1)
  
	### Output is list of boolean lists for each row ###
	output = []  
	for d in dicts :
		l = []
		i = 0
		for status in states :
			if d[states[i][0]] == states[i][1]:
				l.append(True)
			else : 
				l.append(False)
			i = i + 1
		output.append(l)
	return (states, output)

def sortItems(items) :
	res1 = []
	for item in items :
		res1.append(item[0] + '$&/$'+ item[1])
	res1.sort()
	res = []
	for item in res1 :
		div = item.split('$&/$')
		res.append((div[0], div[1]))
	return res
	
		
