import DataForming
from FPGrowthTools import *
from FPGrowthNode import *


class FPGrowth() :
	''' The FPGrowth-Algorithm searches for frequent sets in a boolean table.
		In the implementation, either a string(boolean) or a string(value) table are accepted.
		In the second case, a boolean table is generated
		transactions : are itemsets appearing in the boolean table
		FPTree : root of generated FPTree, consisting of FPNodes
		frequendItemsSets : itemsets that appear more often than given minsupport
	'''

	def __init__(self, minsup, path, flag, pop) :
		if flag == 'boolean' :
			self.data = DataForming.readBooleanTable(path)
		elif flag == 'stringvalues' :
			self.data = DataForming.makeBooleanTable_popId(path, pop)
		else :
			print '[ERROR] no proper flag : %s' %flag
			return

		self.states = self.data[0]
		print '*** States = %s ***'
		for state in self.states :
			print ' - %s' %str(state)
		self.table = self.data[1]
		self.transactions = findTransactions(self.table, self.states)

		self.FPTree = buildTree(constructRoot('root'), self.transactions, minsup)
		self.frequentItemsSets = self.generateFrequentItemSets()

	def generateFrequentItemSets(self) :
		''' starting in the leaves of the tree -> last item since lexicographically ordered 
		'''
		i = len(self.states)-1
		itemSetList = []
		while i >= 0 :
			setsOfItem = self.findFreqOfItem(self.states[i])
			itemSetList = itemSetList + setsOfItem
			i = i-1
		return itemSetList


	def findFreqOfItem(self, item) :
		''' first loop : starts with certain item
			only looks for itemsets with items < item
			1) bulid Prefix tree (tree only with branches ending in item) -> check support of item -> (go on / return)
			2) build Conditional tree (through out unfrequent items + cut off leaves)
			3) declare remaining itemsets in Conditional tree as frequent
			4) Recursion : for each ramining item : build Prefix tree
		'''
		freqItems = []
		pT = builtPrefixTree(item, [], self.FPTree)
		
		if not pT.root.isNullNode() :
			freqItems.append(([item], getNodeFreq(pT.lastNodeOfItem[item])))
			condiTree = kickInfreqItemsFrom(pT, item)
			if not condiTree.root.isNullNode() :
				indexOfItem = self.states.index(item)
				restItems = self.states[0:indexOfItem]
				for restItem in restItems :
					freqItems = freqItems + self.findFreqOfItemSet(restItem, [item], condiTree)
			return freqItems
		else :
			return []


	def findFreqOfItemSet(self, restItem, itemSet, condiTree) :
		''' function needed in recursion 4)
			Input : restItem = one of remaining item, itemSet = item set that is already proven to be frequent
			Return : eventually frequent itemsets containing restItem and itemSet (and other items < restItem)
		'''
		
		freqItems = []
		if restItem in condiTree.lastNodeOfItem.keys() :
			nextpT = builtPrefixTree(restItem, itemSet, condiTree)
		else :
			return []

		if not nextpT.root.isNullNode() :
			freqItems.append(([restItem] + itemSet, getNodeFreq(nextpT.lastNodeOfItem[restItem])))
			nextCondiTree = kickInfreqItemsFrom(nextpT, restItem)
			if not nextCondiTree.root.isNullNode() :
				popItems = copyList(itemSet)
				popItems.append(restItem)
				restItems = []
				for state in self.states :
					if not state in popItems :
						restItems.append(state)

				for nextRestItem in restItems :
					freqItems = freqItems + self.findFreqOfItemSet(nextRestItem, popItems, nextCondiTree)

		return freqItems
			







	



				

		
