

class FPNode() :
	''' represents a Node in a Tree
		label : a tuple of (header, value) taken from csv table
		count : how often the node is represented in transactions
		parent : is parent node
		next : list of children nodes
		same : node with same label or nullNode
	'''

	def __init__(self, l, c, p, n, s) :
		self.label = l
		self.count = c
		self.parent = p
		self.next = n 
		self.same = s

	# next
	def hasAsNext(self, item) :
		''' returns boolean wheather self has a childe with label item
		'''
		for node in self.next :
			if node.hasLabel(item) :
				return True
		return False		

	def addNext(self, item) :
		''' adds a new node with label item to self
			count = 0, is incremented in alorithm
		'''
		nextNode = FPNode(item, 0, self, [], nullNode())
		self.next.append(nextNode)

	def goToNext(self, item) :
		''' returns children node with label item
		'''
		for node in self.next :
			if node.hasLabel(item) :
				return node
		print '[ERROR] no next'

	# tiny helper
	def isNullNode(self) :
		return self.hasLabel(('nullnode', 'nn'))

	def isRoot(self) :
		return self.label[0] == 'root'

	def hasLabel(self, label) :
		return self.label[0] == label[0] and self.label[1] == label[1]

	def increment(self) :
		self.count = self.count + 1

	# print
	def printNode(self) :
		print '( Node %s as %s ' % (str(self.label), self)
		print '   >with count = %s and same = %s ' %(self.count, self.same)
		for node in self.next :
			node.printNode()
		print ') end Node %s ' % self
	
	def printNodeMin(self) :
		print '(%s:%s ' %(str(self.label), self.count)
		for node in self.next :
			node.printNodeMin()
		print '----)%s' %str(self.label)

class FPTree() :
	''' used to combine root and lastNodeOfItem
		instead of a tuple
	'''

	def __init__(self, root, lastNodeOfItem, minsupport) :
		self.root = root
		self.lastNodeOfItem = lastNodeOfItem
		self.minsupport = minsupport


# some common Stuctures
def constructRoot(name) :
	return FPNode(('root', name), -1, nullNode(), [], nullNode())

def nullNode() :
	return FPNode(('nullnode', 'nn'), -1, -1, -1, -1)

def nullTree() :
	return FPTree(nullNode(), dict(), -1)




